#include <iostream>
#include <graphics.h>
#include <math.h>

void plotcircle(int x1, int y1, int x2, int y2)
{
	putpixel(x1 + x2, y1 + y2, WHITE);
	putpixel(x1 - x2, y1 + y2, WHITE);
	putpixel(x1 + x2, y1 - y2, WHITE);
	putpixel(x1 - x2, y1 - y2, WHITE);
	putpixel(x1 + y1, y1 + x2, WHITE);
	putpixel(x1 - y1, y1 + x2, WHITE);
	putpixel(x1 + y1, y1 - x2, WHITE);
	putpixel(x1 - y1, y1 - x2, WHITE);
}

void brescircle(int x1, int y1, int r)
{
	int x2 = 0;
    	int y2 = r;
    	int p = 3-2*r;

	plotcircle(x1, y1, x2, y2);

	while (x2 <= y2) 
{
        x2++;
        if (p < 0) {
            p += 4 * x2 + 6;
        } else {
            y2--;
            p += 4*(x2-y2)+10;
        }
        plotcircle(x1, y1, x2, y2);
}

}

int main()
{
    int gd = DETECT, gm;
    initgraph(&gd, &gm,NULL);
    brescircle(200, 200, 100);
    getch();     
    closegraph();
    return 0;
}




