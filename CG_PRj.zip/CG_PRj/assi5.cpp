#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{
	string firstName, middleName, lastName;
	cout << "Enter your full name: ";
	cin >>firstName;
	cin >>middleName;
	cin >>lastName;


	cout << firstName[0] << "." << middleName[0] << "." << lastName <<"\n";
	return 0;
}
