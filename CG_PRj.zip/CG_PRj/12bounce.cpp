#include <graphics.h>
#include <chrono>
#include <thread>
#include <cmath>
void drawBouncingBall() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, NULL);

    int ballX = 100;               
    int ballY = getmaxy() / 2;     
    int ballRadius = 15;           
    int xSpeed = 2;                
    int sineAmplitude = 50;        
    float frequency = 0.05;        
    int maxX = getmaxx();         
    int maxY = getmaxy();         

   
    int ballColor = RED;
    setcolor(ballColor);

    for (int i = 0; i < 1000; ++i) { 

        cleardevice();

      
        ballY = getmaxy() / 2 + sineAmplitude * sin(frequency * ballX);
        
  
        circle(ballX, ballY, ballRadius);
        floodfill(ballX, ballY, ballColor); 

        
        ballX += xSpeed;

       
        if (ballX + ballRadius >= maxX || ballX - ballRadius <= 0) {
            xSpeed = -xSpeed; 
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    closegraph();
}

int main() {
    drawBouncingBall();
    return 0;
}
