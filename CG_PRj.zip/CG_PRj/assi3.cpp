#include<iostream>
using namespace std;

class Employee
{
public:
string name;
int salary, workhours;
void getinfo ()
{


cout<<"Enter Your name:";
cin>>name;
cout<<"Enter Your salary:";
cin>>salary;
cout<<"Enter Your work hours per day:";
cin>> workhours;
}
void addSal ()
{
if(salary<50000)
{
	salary +=10000;
	cout<< "your salary is: \n" <<salary;

}
}
void addWork ()
{
if(workhours>6)
{
	salary +=1000;
	cout<<"your work hours is: \n" <<workhours;
}
}
};

int main()
{
Employee gi;
gi.getinfo();
gi.addSal();
gi.addWork();

return 0;
}


