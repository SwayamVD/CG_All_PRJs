#include <iostream>
#include <stdio.h>
using namespace std;
class Directory 
{
	public:
	string name;
	string add;
	long int teleNum;
	long int mobNum;
	string headOfFamily;
	void getInfo()
	{
	cout << "Name: " << name <<"\n";
	cout << "Address: " << add <<"\n";
	cout << "Telephone Number: " << teleNum <<"\n";
	cout << "Mobile number: " << mobNum <<"\n";
	cout << "Head Of Family: " << headOfFamily <<"\n";
	}
};

int main()
{
Directory d;
d.name ="Bhumi";
d.add ="Nashik";
d.teleNum = 25698745;
d.mobNum =9876543210;
d.headOfFamily ="Ram";
d.getInfo();
return 0;
}
