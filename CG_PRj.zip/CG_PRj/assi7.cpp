#include <iostream>
#include <stdio.h>
#include <stdexcept>
using namespace std;
int main()
{
	int age;
	cout <<"Enter Age: ";
	cin >> age;
	float sal;
	cout <<"Enter Salary: ";
	cin >> sal;
	string city;
	cout <<"Enter city: ";
	cin >> city;
	string vehicle;
	cout <<"Enter vehicle: ";
	cin>> vehicle;
	try
	{
	if(age>=18 && age<=55)
		{
		throw runtime_error("Your age is not valid.");
		}
	}
	catch(const exception e)
	{
	cout <<"Exception: " <<e.what();
	}

	try
	{
	if(sal>=50000 && sal<=100000)
		{
		throw runtime_error("Your salary is not valid.");
		}
	}
	catch(const exception ex)
	{
	cout <<"Exception: " <<ex.what();
	}

	try
	{
	if(city != "Pune" || city != "Mumbai" || city != "Banglore" || city != "Chennai")
		{
		throw runtime_error("Your city is not valid.");
		}
	}
	catch(const exception exp)
	{
	cout <<"Exception: " <<exp.what();
	}

	try
	{
	if(vehicle !="Yes" )
		{
		throw runtime_error("You should have a 4 wheeler.");
		}
	}
	catch(const exception expc)
	{
	cout <<"Exception: " <<expc.what();
	}
}
