#include<iostream>
#include<math.h>
#include<graphics.h>
int main()
{
	int gd = DETECT, gm;
	initgraph(&gd, &gm, NULL);
	line(212,350,388,350);
	line(215,350,300,200);
	line(300,200,388,350);
	circle(300,300,50);
	circle(300,300,100);
	getch();
	delay(10000);
	closegraph();
	return 0;
}
