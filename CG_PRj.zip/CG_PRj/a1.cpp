#include <iostream>
#include <graphics.h>

int main()
{
	int gd,gm;
	gd = DETECT;
	initgraph(&gd,&gm,NULL);
	line(270,150,150,210);
	line(150,210,270,270);
	line(270,150,400,210);
	line(270,270,400,210);
	rectangle(150,150,400,270);
	circle(270,210,55);
	delay(9000);
	return 0;
	getch();
	closegraph();
}
