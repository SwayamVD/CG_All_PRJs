#include <iostream>
#include <graphics.h>
#include <cmath>
using namespace std;
int rotation(int x, int y, int angle)
{
	float radian = angle * M_PI / 180.0;
	x = x * cos(radian) - y * sin(radian);
	y = x * sin(radian) + y * cos(radian);
	return x, y;
}
int translation(int x, int y, int tx, int ty)
{
	x = x + tx;
	y= y + ty;
	return x, y;
}
int scale(int x, int y, int sx, int sy)
{
	x = x * sx;
	y = y * sy;
	return x, y;
}
int main()
{
	int choice, tx, ty, angle, Sx, Sy, ch;
	int gd = DETECT, gm;
	int x1 = 320, x2 = 400, x3 = 250;
	int y1 = 150, y2 = 250, y3 = 320;
	do
	{
		cout<<"Choice of 2-D transformations: \n1. Translation\n2. Rotation\n3. Scaling\n";
		cin>>choice;
		switch(choice)
		{
			case 1: 
			cout<<"Enter translation vector (tx, ty): \n";
			cin>>tx>>ty;
			initgraph(&gd, &gm, "");
			cleardevice();
			setcolor(RED);
			line(x1, y1, x2, y2);
			line(x2, y2, x3, y3);
			line(x3, y3, x1, y1);
			translation(x1, y1, tx, ty);
			translation(x2, y2, tx, ty);
			translation(x3, y3, tx, ty);
			delay(1000);
			setcolor(GREEN);
			line(x1, y1, x2, y2);
 			line(x2, y2, x3, y3);
 			line(x3, y3, x1, y1);
 			getch();
			closegraph();
			break;
			
			case 2:
			cout<<"Enter angle in degrees: \n";
			cin>>angle;
			initgraph(&gd, &gm, "");
			cleardevice();
			setcolor(RED);
			line(x1, y1, x2, y2);
			line(x2, y2, x3, y3);
			line(x3, y3, x1, y1);
			rotation(x1, y1, angle);
			rotation(x2, y2, angle);
			rotation(x3, y3, angle);
			delay(1000);
			setcolor(GREEN);
			line(x1, y1, x2, y2);
 			line(x2, y2, x3, y3);
 			line(x3, y3, x1, y1);
			getch();
			closegraph();
			break;
			
			case 3:
			cout<<"Enter scaling vector (Sx, Sy); \n";
			cin>>Sx>>Sy;
			initgraph(&gd, &gm, "");
			cleardevice();
			setcolor(RED);
			line(x1, y1, x2, y2);
			line(x2, y2, x3, y3);
			line(x3, y3, x1, y1);
			scale(x1, y1, Sx, Sy);
			scale(x2, y2, Sx, Sy);
			scale(x3, y3, Sx, Sy);
			delay(1000);
			setcolor(GREEN);
			line(x1, y1, x2, y2);
 			line(x2, y2, x3, y3);
 			line(x3, y3, x1, y1);
			getch();
			closegraph();
			break;
			
			default:
			cout<<"Invalid choice. Choose between 1, 2, 3.\n";
			break;
		}
		cout<<"If you wish to continue, press 1\n";
		cin>>ch;
	}
	while(ch == 1);
	return 0;
}
