#include<iostream>
#include<graphics.h>
void floodfill(int x, int y, int fc, int dc){
	if(getpixel(x,y)==dc){
		putpixel(x,y,fc);
		floodfill(x+1,y,fc,dc);
		floodfill(x-1,y,fc,dc);
		floodfill(x,y+1,fc,dc);
		floodfill(x,y-1,fc,dc);
	}
}
int main(){
	int gd = DETECT, gm;
	initgraph(&gd,&gm,NULL);
	rectangle(50,50,100,100);
	floodfill(55,55,4,15);
	getch();
	closegraph();
	return 0;
}
