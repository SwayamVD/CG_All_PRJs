#include <iostream>
#include <stdio.h>
using namespace std;
class Fruits{
	public:
	string frts[5] = {"Apple", "Strawberry", "Mango", "Cherry", "Apple" };
	void countFruits(){
		for(int i; i <= sizeof(frts) ; i++){
			cout << frts[i] << " ";
		}
		cout <<"Total Number of Fruits in Basket: "<< sizeof(frts);
	}
};

class Apples : public Fruits{
	public:
	void cntApple(){
		int cnt=0;
		int frt = sizeof(frts);
		for(int i = 0; i <= frt; i++){
			if(frts[i] == "Apple"){
				cnt++;
			}
		}
		cout << "Total Apples in Basket: " << cnt << "\n";
	}
};
class Mangoes : public Fruits{
	public:
	void cntMangoes(){
		int cnt = 0;
		int frt = sizeof(frts);
		for(int i= 0; i<=frt;i++){
			if(frts[i] == "Mango"){
				cnt++;
			}
		}
		cout << "Total Mangoes in Basket: " << cnt << "\n";
	}
};

int main(){
	Fruits f;
	f.countFruits();
	Apples a;
	a.cntApple();
	Mangoes m;
	m.cntMangoes();
	return 0;
}
