#include <iostream>
#include <graphics.h>

void ddaline(int x1, int y1, int x2, int y2)
{
	int dx = x2-x1;
	int dy = y2-y1;
	int steps;
	float xInc, yInc;
	float x = x1;
	float y =y1;
	steps = (abs(dx) > abs(dy)) ? abs(dx) : abs(dy);
    	xInc = dx / static_cast<float>(steps);
    	yInc = dy / static_cast<float>(steps);


	for (int i = 0; i <= steps; ++i) 
{
        putpixel(static_cast<int>(round(x)), static_cast<int>(round(y)), WHITE);
        x += xInc;
        y += yInc;
}
}

int main() {
  
    int gd = DETECT, gm;
    initgraph(&gd, &gm,NULL);  
    ddaline(100, 100, 200, 100);
    getch();   
    closegraph();

    return 0;
}
