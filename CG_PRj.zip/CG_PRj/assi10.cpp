#include <iostream>
#include <graphics.h>
#include <math.h>
using namespace std;

static int LEFT = 1, RIGHT = 2, BOTTOM = 4, TOP = 8, xmax, ymax, xmin, ymin;

int getcode(int x, int y) {
    int code = 0;
    if (y > ymax) code |= TOP;
    if (y < ymin) code |= BOTTOM;
    if (x < xmin) code |= LEFT;
    if (x > xmax) code |= RIGHT;
    return code;
}

float max(float a, float b) {
    return (a > b) ? a : b;
}

float min(float a, float b) {
    return (a < b) ? a : b;
}

void line1(int x1, int y1, int x2, int y2) {
    float len;
    float dx = x2 - x1;
    float dy = y2 - y1;

    len = max(max(dx, dy), -dx); 
    
    float xin = dx / len; 
    float yin = dy / len;
    float x = x1;
    float y = y1;

    for (int i = 0; i <= len; i++) {
        putpixel(round(x), round(y), RED);
        x += xin;
        y += yin;
    }
}

int main() {
    int gd = DETECT, gm;
    int x1, y1, x2, y2;

    cout << "Enter top left and bottom right coordinates: ";
    cin >> xmin >> ymin >> xmax >> ymax;
    cout << "Enter endpoints of line: ";
    cin >> x1 >> y1 >> x2 >> y2;

    initgraph(&gd, &gm, NULL);
    
    rectangle(xmin, ymin, xmax, ymax);
    line1(x1, y1, x2, y2);
    delay(1000); 
    int outcode1 = getcode(x1, y1);
    int outcode2 = getcode(x2, y2);
    int accept = 0;

    while (true) {
        float m = (float)(y2 - y1) / (x2 - x1);
        
        if (outcode1 == 0 && outcode2 == 0) {
            accept = 1;
            break;
        } else if ((outcode1 & outcode2) != 0) {
            break;
        } else {
            int x, y;
            int temp = (outcode1 == 0) ? outcode2 : outcode1;

            if (temp & TOP) {
                x = x1 + (ymax - y1) / m;
                y = ymax;
            } else if (temp & BOTTOM) {
                x = x1 + (ymin - y1) / m;
                y = ymin;
            } else if (temp & LEFT) {
                x = xmin;
                y = y1 + m * (xmin - x1);
            } else if (temp & RIGHT) {
                x = xmax;
                y = y1 + m * (xmax - x1);
            }

            
            if (temp == outcode1) {
                x1 = x;
                y1 = y;
                outcode1 = getcode(x1, y1);
            } else {
                x2 = x;
                y2 = y;
                outcode2 = getcode(x2, y2);
            }
        }
    }
    
    setcolor(BROWN);
    cleardevice();
    rectangle(xmin, ymin, xmax, ymax); 
    
    if (accept) {
        line1(x1, y1, x2, y2); 
    }

    getch();
    closegraph();

    return 0;
}

