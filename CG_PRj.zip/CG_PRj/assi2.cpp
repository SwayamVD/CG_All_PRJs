#include<iostream>
using namespace std;

int main()
{
int marks;

cout<<"Enter your marks:";
cin>>marks;

if(marks>=90){
cout<<"O grade";
}

else if(marks>=81 && marks<90){
cout<<"A grade";
}

else if(marks>=71 && marks<=80){
cout<<"B grade";
}

else if(marks>=61 && marks<=70){
cout<<"C grade";
}

else if(marks>=51 && marks<=60){
cout<<"D grade";
}

else if (marks>=41 && marks<=50){
cout<<"E grade";
}

else {
cout<<"F grade \n ";
}

return 0;
}

