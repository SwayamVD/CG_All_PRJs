#include <iostream>
#include <graphics.h>
void seedfill(int x, int y, int fc, int bc){
	if(getpixel(x,y) != bc && getpixel(x,y) != fc){
		putpixel(x, y, fc);
		seedfill(x+1,y,fc,bc);
		seedfill(x,y+1,fc,bc);	
		seedfill(x-1,y,fc,bc);
		seedfill(x,y-1,fc,bc);
		seedfill(x-1,y-1,fc,bc);
		seedfill(x-1,y+1,fc,bc);
		seedfill(x+1,y+1,fc,bc);
		seedfill(x+1,y+1,fc,bc);
	}
}
int main(){
	int gd = DETECT, gm;
	initgraph(&gd,&gm,NULL);
	rectangle(50,50,100,100);
	seedfill(55,55,4,15);
	getch();
	closegraph();
	return 0;
}
